<?php
// Text
$_['text_footer'] 	= '<a href="http://www.opencart.com">OpenCart</a> &copy; 2009-' . date('Y') . ' All Rights Reserved.<br /> Tradus de <a target="_blank" href="http://shopencart.com/">SO</a> și <a target="_blank" href="http://shopthemer.com">ST</a>';
$_['text_version'] 	= 'Versiunea %s';