<?php
$_['text_complete_status']   = 'Comenzi finalizate'; 
$_['text_processing_status'] = 'Comenzi în procesare'; 
$_['text_other_status']      = 'Alte Statusuri'; 