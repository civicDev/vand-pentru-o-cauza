<?php
// Heading
$_['heading_title']    = 'Comision de desfacere';

// Text
$_['text_total']       = 'Totalul Comenzii';
$_['text_success']     = 'Succes: Ai modificat totalul comision de desfacere!';
$_['text_edit']        = 'Editeaza comsionul de desfacere';

// Entry
$_['entry_total']      = 'Totalul Comenzii';
$_['entry_fee']        = 'Comision';
$_['entry_tax_class']  = 'Clasa de taxe';
$_['entry_status']     = 'Status';
$_['entry_sort_order'] = 'Ordine Sortare';

// Help
$_['help_total']       = 'Valarea pe care trebuie sa o atinga comanda inainte ca acest total sa devina activ.';

// Error
$_['error_permission'] = 'Eroare: Nu ai permisiunile necesare pentru a modifica această pagină. Contactează administratorul pentru asistență. Daca ești administrator mergi in admin la grupuri de utilizatori și actualizează permisiunile!';