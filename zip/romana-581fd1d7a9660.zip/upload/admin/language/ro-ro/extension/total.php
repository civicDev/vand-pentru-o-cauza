<?php
// Heading
$_['heading_title']     = 'Totaluri Comenzi';

// Text
$_['text_success']      = 'Succes: Ai modificat totalurile!';
$_['text_list']         = 'Listă Totaluri';

// Column
$_['column_name']       = 'Totaluri Comenzi';
$_['column_status']     = 'Status';
$_['column_sort_order'] = 'Ordine Sortare';
$_['column_action']     = 'Acțiune';

// Error
$_['error_permission']  = 'Eroare: Nu ai permisiunile necesare pentru a modifica această pagină. Contactează administratorul pentru asistență. Daca ești administrator mergi in admin la grupuri de utilizatori și actualizează permisiunile!';