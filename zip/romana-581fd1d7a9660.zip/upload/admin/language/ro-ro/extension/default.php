<?php
$_['lang_openbay_new']              = 'Creați o nouă listă';
$_['lang_openbay_edit']             = 'Vezi / Editeaza lista';
$_['lang_openbay_fix']              = 'Fixeaza erorile';
$_['lang_openbay_processing']       = 'Prelucrare';

$_['lang_amazonus_saved']           = 'Salvate (not uploaded)';
$_['lang_amazon_saved']             = 'Salvate (not uploaded)';
$_['lang_play_pending_new']         = 'In așteptare (nou)';
$_['lang_play_pending_updated']     = 'In așteptare (actualizat)';
$_['lang_play_warning']             = 'Mesajele de avertizare';
$_['lang_play_pending_delete']      = 'În așteptarea ștergerii';
$_['lang_play_stock_updating']      = 'Actualizarea stoc';

$_['lang_markets']                  = 'Markets';
$_['lang_bulk_btn']                 = 'eBay încărcare masivă';

$_['lang_marketplace']              = 'Marketplace';
$_['lang_status']                   = 'Statut';
$_['lang_option']                   = 'Optiune';