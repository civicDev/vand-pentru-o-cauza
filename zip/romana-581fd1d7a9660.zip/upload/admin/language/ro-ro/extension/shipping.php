<?php
// Heading
$_['heading_title']     = 'Metode de livrare';

// Text
$_['text_success']      = 'Succes: Ai modificat metodele de livrare!';
$_['text_list']         = 'Listă Metode de Livrare';

// Column
$_['column_name']       = 'Metoda De Livrare';
$_['column_status']     = 'Status';
$_['column_sort_order'] = 'Ordine Sortare';
$_['column_action']     = 'Acțiune';

// Error
$_['error_permission']  = 'Eroare: Nu ai permisiunile necesare pentru a modifica această pagină. Contactează administratorul pentru asistență. Daca ești administrator mergi in admin la grupuri de utilizatori și actualizează permisiunile!';