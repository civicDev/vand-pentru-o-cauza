<?php
// Heading 
$_['heading_title']    = 'Manager de Extensii';

// Text
$_['text_success']     = 'Succes: Ai instalat extensia!';

// Error
$_['error_permission'] = 'Atentie: Nu ai permisiunea sa modifici managerul de extensii!';
$_['error_upload']     = 'Incarcare necesara!';
$_['error_filetype']   = 'Tip fisier invalid!';
?>