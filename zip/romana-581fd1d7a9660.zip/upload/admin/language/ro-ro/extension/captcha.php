<?php
// Heading
$_['heading_title']    = 'Captcha (Cod de Verificare)';

// Text
$_['text_success']     = 'Succes: Ai modificat Captcha!';
$_['text_list']        = 'Lista extensiilor';

// Column
$_['column_name']      = 'Nume';
$_['column_status']    = 'Status';
$_['column_action']    = 'Acțiune';

// Error
$_['error_permission'] = 'Avertizare: Nu ai permisiunea să modifici Captcha!';
