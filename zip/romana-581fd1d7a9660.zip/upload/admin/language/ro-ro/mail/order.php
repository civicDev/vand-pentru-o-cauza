<?php
// Text
$_['text_subject']      = '%s - Updatarea Comenzii %s';
$_['text_order']        = 'ID-ul Comenzii:';
$_['text_date_added']   = 'Data Comenzii:';
$_['text_order_status'] = 'Comanda dumneavoastră a fost updatată la următorul status:';
$_['text_comment']      = 'Comentariile pentru comanda dumneavoastră sunt:';
$_['text_link']         = 'Ca să vizualizați cererile dumneavoastră apăsați pe linkul de mai jos:';
$_['text_footer']       = 'Vă rugăm să ne contactați pe această adresă de e-mail dacă aveți întrebări.';
?>