<?php
// Text
$_['text_subject']  = 'Ai primit un voucher cadoul de la %s';
$_['text_greeting'] = 'Felicitări! Ai primit un Voucher Cadou, în valoare de %s';
$_['text_from']     = 'Acest Voucher Cadou ți-a fost trimis de către %s';
$_['text_message']  = 'Cu următorul mesaj';
$_['text_redeem']   = 'Pentru a dobandi acest Voucher Cadou, scrie codul care este <b>%s</b> apoi apasă pe linkul de mai jos și cumpără produsul pe care il dorești, folosind și voucherul cadou. Poți să introduci codul voucherului cadou pe pagina coșului de cumpăraturi, înainte să apeși butonul cumpărare.';
$_['text_footer']   = 'Terugăm să ne contactezi pe această adresă de e-mail dacă ai întrebări.';