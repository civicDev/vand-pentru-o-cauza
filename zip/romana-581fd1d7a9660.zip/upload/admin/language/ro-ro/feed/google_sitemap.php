<?php
// Heading
$_['heading_title']    = 'Sitemap Google';

// Text
$_['text_feed']        = 'Feed-uri';
$_['text_success']     = 'Succes: Ai modificat feed-ul Google Sitemap!';
$_['text_edit']        = 'Editează Google Sitemap';

// Entry
$_['entry_status']     = 'Status';
$_['entry_data_feed']  = 'URL Feed';

// Error
$_['error_permission'] = 'Eroare: Nu ai permisiunile necesare pentru a modifica această pagină. Contactează administratorul pentru asistență. Daca ești administrator mergi in admin la grupuri de utilizatori și actualizează permisiunile!';