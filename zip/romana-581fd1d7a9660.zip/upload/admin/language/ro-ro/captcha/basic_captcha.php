<?php
$_['heading_title']    = 'Captcha Intern';

// Text
$_['text_captcha']     = 'Captcha';
$_['text_success']	   = 'Succes: Ai modificat captcha intern!';
$_['text_edit']        = 'Editează Captcha Intern (sistem captcha inclus in opencart)';

// Entry
$_['entry_status']     = 'Status';

// Error
$_['error_permission'] = 'Avertizare: Nu ai permisiunea să modifici Captcha Intern!';
