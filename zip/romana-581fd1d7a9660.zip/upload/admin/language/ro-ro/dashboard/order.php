<?php
// Heading
$_['heading_title'] = 'Comenzi Totale';

// Text
$_['text_view']     = 'Vezi mai mult...';