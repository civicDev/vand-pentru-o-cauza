<?php
// Heading
$_['heading_title'] = 'Hartă';

$_['text_order']    = 'Comenzi';
$_['text_sale']     = 'Vânzări';