<?php
// Heading
$_['heading_title'] = 'Total Clienți';

// Text
$_['text_view'] = 'Vezi mai mult...';