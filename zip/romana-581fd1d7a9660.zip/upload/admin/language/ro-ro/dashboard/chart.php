<?php
// Heading
$_['heading_title'] = 'Statistici Vânzări';

// Text
$_['text_order']    = 'Comenzi';
$_['text_customer'] = 'Clienţi';
$_['text_day']      = 'Astăzi';
$_['text_week']     = 'Săptămâna';
$_['text_month']    = 'Ultima Lună';
$_['text_year']     = 'Ultimul An';