<?php
// Heading
$_['heading_title']     = 'Raportul Comisionului Afiliaților';

// Text
$_['text_list']         = 'Lista Comisionului Afiliaților';

// Column
$_['column_affiliate']  = 'Nume Afiliat';
$_['column_email']      = 'E-mail';
$_['column_status']     = 'Status';
$_['column_commission'] = 'Comision';
$_['column_orders']     = 'Număr  Comenzi';
$_['column_total']      = 'Total';
$_['column_action']     = 'Acţiune';

// Entry
$_['entry_date_start']  = 'Data Începerii';
$_['entry_date_end']    = 'Data Încheierii';