<?php
// Heading
$_['heading_title']     = 'Raport Clienți Online';

// Text
$_['text_list']         = 'Listă Clienți Online';
$_['text_guest']        = 'Musafir';

// Column
$_['column_ip']         = 'IP';
$_['column_customer']   = 'Client';
$_['column_url']        = 'Ultima Pagină Vizitată';
$_['column_referer']    = 'Referer';
$_['column_date_added'] = 'Ultimul Click';
$_['column_action']     = 'Acţiune';

// Entry
$_['entry_ip']          = 'IP';
$_['entry_customer']    = 'Client';