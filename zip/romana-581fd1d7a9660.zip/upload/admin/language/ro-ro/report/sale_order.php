<?php
// Heading
$_['heading_title']     = 'Raport Vânzări';

// Text
$_['text_list']         = 'LIstă Vânzări';
$_['text_year']         = 'Ani';
$_['text_month']        = 'Luni';
$_['text_week']         = 'Săptămâni';
$_['text_day']          = 'Zile';
$_['text_all_status']   = 'Toate Statusurile';

// Column
$_['column_date_start'] = 'Data Începerii';
$_['column_date_end']   = 'Data Încheierii';
$_['column_orders']     = 'Nr. Comenzi';
$_['column_products']   = 'Nr. Produse';
$_['column_tax']        = 'Taxa';
$_['column_total']      = 'Total';

// Entry
$_['entry_date_start']  = 'Data Începerii';
$_['entry_date_end']    = 'Data Încheierii';
$_['entry_group']       = 'Groupează După';
$_['entry_status']      = 'Statuslui Comenzii';