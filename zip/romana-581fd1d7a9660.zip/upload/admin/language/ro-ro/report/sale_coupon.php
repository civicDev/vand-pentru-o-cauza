<?php
// Heading
$_['heading_title']    = 'Raport Cupoane';

// Text
$_['text_list']        = 'Listă Cupoane';

// Column
$_['column_name']      = 'Nume Cupon';
$_['column_code']      = 'Cod';
$_['column_orders']    = 'Comenzi';
$_['column_total']     = 'Total';
$_['column_action']    = 'Acțiune';

// Entry
$_['entry_date_start'] = 'Data Începerii';
$_['entry_date_end']   = 'Data Încheierii';