<?php
// Heading
$_['heading_title']    = 'Raport Marketing';

// Text
$_['text_list']         = 'Listă Marketing';
$_['text_all_status']   = 'Toate Statusurile';

// Column
$_['column_campaign']  = 'Nume Campanie';
$_['column_code']      = 'Cod';
$_['column_clicks']    = 'Click-uri';
$_['column_orders']    = 'Număr  Comenzi';
$_['column_total']     = 'Total';

// Entry
$_['entry_date_start'] = 'Data Începerii';
$_['entry_date_end']   = 'Data Încheierii';
$_['entry_status']     = 'Statusul comenzii';