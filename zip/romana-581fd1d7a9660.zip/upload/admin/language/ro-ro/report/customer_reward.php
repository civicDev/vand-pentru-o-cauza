<?php
// Heading
$_['heading_title']         = 'Raport Puncte Recompensă Clienți';

// Text
$_['text_list']             = 'Listă Puncte Recompensă Clienți';

// Column
$_['column_customer']       = 'Nume Client';
$_['column_email']          = 'E-Mail';
$_['column_customer_group'] = 'Grup Client';
$_['column_status']         = 'Status';
$_['column_points']         = 'Puncte Recompensă';
$_['column_orders']         = 'Nr. Comenzi';
$_['column_total']          = 'Total';
$_['column_action']         = 'Acțiune';

// Entry
$_['entry_date_start']      = 'Data Începerii';
$_['entry_date_end']        = 'Data Încheierii';