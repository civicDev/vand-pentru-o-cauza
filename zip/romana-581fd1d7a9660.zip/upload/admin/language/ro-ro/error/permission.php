<?php
// Heading
$_['heading_title']   = 'Permisiune Refuzată!';

// Text
$_['text_permission'] = 'Nu ai permisiunea de a accesa această pagină, te rugăm să consulţi administratorul de sistem.';