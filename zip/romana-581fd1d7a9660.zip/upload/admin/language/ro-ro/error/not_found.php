<?php
// Heading
$_['heading_title']  = 'Pagina nu a fost găsită!';

// Text
$_['text_not_found'] = 'Imposibil de găsit pagina caută! Contactează administratorul în cazul în care problema persistă.';