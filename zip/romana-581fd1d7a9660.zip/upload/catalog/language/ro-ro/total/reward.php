<?php
// Heading
$_['heading_title'] = 'Aplică punctele tale de recompensă (%s disponibile)';

// Text
$_['text_reward']   = 'Puncte de recompensă(%s)';
$_['text_order_id'] = 'ID Comandă: #%s';
$_['text_success']  = 'Succes: Punctele de recompensă au fost aplicate!';

// Entry
$_['entry_reward']  = 'Puncte ce pot fi folosite (Maxim %s)';

// Error
$_['error_reward']  = 'Atenție: Introdu numărul de puncte de recompensă pe care dorești să le folosești!';
$_['error_points']  = 'Atenție: Nu ai %s puncte de recompensă!';
$_['error_maximum'] = 'Atenție: Numărul maxim de puncte ce pot fi folosite este %s!';