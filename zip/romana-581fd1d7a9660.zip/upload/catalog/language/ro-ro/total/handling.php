<?php
$_['text_handling'] = 'Comision de desfacere';