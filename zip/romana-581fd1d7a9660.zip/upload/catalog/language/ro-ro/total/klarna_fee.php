<?php
$_['text_klarna_fee'] = 'Taxă Klarna';