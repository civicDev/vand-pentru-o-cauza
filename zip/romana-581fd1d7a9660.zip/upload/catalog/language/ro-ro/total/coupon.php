<?php
// Text
$_['text_coupon'] = 'Cupon de discount(%s)';
// Heading
$_['heading_title'] = 'Aplică un cupon de discount';

// Text
$_['text_success']  = 'Succes: Cuponul de discount a fost aplicat!';

// Entry
$_['entry_coupon']  = 'Introdu codul cuponului';

// Error
$_['error_coupon']  = 'Atentie: Cuponul de discount este ori invalid ori expirat ori a fost deja folosit la maxim!';
$_['error_empty']   = 'Atentie: Introdu codul cuponului!';