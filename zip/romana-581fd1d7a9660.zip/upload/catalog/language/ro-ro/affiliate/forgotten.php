<?php
// Heading
$_['heading_title']   = 'Ți-ai uitat parola?';

// Text
$_['text_account']    = 'Cont';
$_['text_forgotten']  = 'Parolă uitată';
$_['text_your_email'] = 'Adresa ta de email';
$_['text_email']      = 'Introdu adresa de email asociată contului tău. Apasă trimitere pentru a primi parola pe e-mail';
$_['text_success']    = 'Succes: O nouă parolă a fost trimisă către tine.';

// Entry
$_['entry_email']     = 'Adresa de e-mail:';

// Error
$_['error_email']     = 'Eroare: Adresa de e-mail nu a fost găsită in baza noastră de date!';