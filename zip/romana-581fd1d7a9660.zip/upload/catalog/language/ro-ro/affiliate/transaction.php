<?php
// Heading
$_['heading_title']      = 'Tranzacțiile tale';

// Column
$_['column_date_added']  = 'Data adăugării';
$_['column_description'] = 'Descriere';
$_['column_amount']      = 'Valoare (%s)';

// Text
$_['text_account']       = 'Cont';
$_['text_transaction']   = 'Tranzacțiile tale';
$_['text_balance']       = 'Balanța ta curentă este:';
$_['text_empty']         = 'Nu ai nicio tranzacție!';