<?php
// Heading
$_['heading_title']        = 'Contul meu de afiliat';

// Text
$_['text_account']         = 'Cont';
$_['text_my_account']      = 'Contul meu de afiliat';
$_['text_my_tracking']     = 'Informații de tracking';
$_['text_my_transactions'] = 'Tranzacțiile mele';
$_['text_edit']            = 'Editează informațiile contului';
$_['text_password']        = 'Schimbă parola ';
$_['text_payment']         = 'Schimbă preferințele de plată';
$_['text_tracking']        = 'Cod de tracking personalizat';
$_['text_transaction']     = 'Vezi istoria tranzacțiilor';