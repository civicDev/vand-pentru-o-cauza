<?php
// Heading
$_['heading_title']    = 'Tracking Afiliați';

// Text
$_['text_account']     = 'Cont';
$_['text_description'] = 'Pentru a ne asigura că ești plătit pentru clienții sosiți de pe situl tău, un cod de tracking trebuie plasat in linkurile ce trimit către noi. Folosește uneltele de mai jos pentru a genera linkuri către situl %s.';

// Entry
$_['entry_code']       = 'Codul tău de tracking';
$_['entry_generator']  = 'Genrator link de tracking';
$_['entry_link']       = 'Link de tracking';

// Help
$_['help_generator']  = 'Scrie numele unui produs către care ai dorii să creezi link';