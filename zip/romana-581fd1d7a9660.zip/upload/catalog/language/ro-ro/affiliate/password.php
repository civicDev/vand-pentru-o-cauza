<?php
// Heading
$_['heading_title']  = 'Schimbă-ţi parola';

// Text
$_['text_account']   = 'Cont';
$_['text_password']  = 'Parola ta';
$_['text_success']   = 'Succes: Parola ta a fost actualizată cu succes.';

// Entry
$_['entry_password'] = 'Noua parolă';
$_['entry_confirm']  = 'Confirmă noua parolă';

// Error
$_['error_password'] = 'Parola trebuie să conțină intre 4 si 20 de caractere!';
$_['error_confirm']  = 'Confirmarea parolei nu se potriveşte!';