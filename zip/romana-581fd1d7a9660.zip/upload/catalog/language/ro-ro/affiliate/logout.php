<?php
// Heading
$_['heading_title'] = 'Ieşire din cont';

// Text
$_['text_message']  = '<p>Ai ieşit din contul tău. Acum poți părăsi calculatorul în siguranţă.</p>';
$_['text_account']  = 'Cont';
$_['text_logout']   = 'Ieşire din cont';