<?php
// Text
$_['text_paid_amazon'] 			= 'Plătit pe Amazon';
$_['text_total_shipping'] 		= 'Livrare';
$_['text_total_shipping_tax'] 	= 'Taxa de livrare';
$_['text_total_giftwrap'] 		= 'Împachetare cadou';
$_['text_total_giftwrap_tax'] 	= 'Text cadou';
$_['text_total_sub'] 			= 'Subtotal';
$_['text_tax'] 					= 'Taxa';
$_['text_total'] 				= 'Total';