<?php
// Heading
$_['heading_title'] = 'Pagina nu a fost gasită!';

// Text
$_['text_error']    = 'Pagina nu a fost gasită.';