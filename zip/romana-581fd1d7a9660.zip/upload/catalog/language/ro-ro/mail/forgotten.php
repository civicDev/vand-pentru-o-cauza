<?php
// Text
$_['text_subject']  = '%s - Noua Parolă';
$_['text_greeting'] = 'O nouă parolă a fost cerută de la %s.';
$_['text_change']   = 'Pentru resetarea parolei, accesați următorul link:';
$_['text_ip']       = 'Cererea de resetare a fos inițiată de IP-ul: %s';
