<?php
// Text
$_['text_subject']  = 'Ai primit un voucher cadou de la %s';
$_['text_greeting'] = 'Felicitări, ai primit un voucher cadou în valoare de %s';
$_['text_from']     = 'Voucherul cadou ți-a fost trimis de către %s';
$_['text_message']  = 'Cu următorul mesaj';
$_['text_redeem']   = 'Pentru a folosi voucherul cadou , notează codul primit, care este <b>%s</b> , apoi urmează linkul următor și cumpără produsul/ele pe care le dorești.Poți introduce codul voucherului cadou pe pagina Coșului de cumpărături, înainte de a face click pe comandă.';
$_['text_footer']   = 'Te rugăm sa răspunzi la acest e-mail dacă ai vreo întrebare.';
