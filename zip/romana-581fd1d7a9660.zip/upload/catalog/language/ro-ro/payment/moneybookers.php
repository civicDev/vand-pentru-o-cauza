<?php
// Text
$_['text_title'] = 'Card Credit / Card Debit (Moneybookers)';