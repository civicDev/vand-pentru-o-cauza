<?php
// Text
$_['text_title']				= 'Card de credit/debit (Plata procesată de PayPal)';
$_['text_secure_connection']	= 'Se creează o conexiune securizată...';

// Error
$_['error_connection']			= 'Conectarea la PayPal a eșuat. Contactează administratorul magazinului pentru asistență sau alege o altă metodă de plată.';