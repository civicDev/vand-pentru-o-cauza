<?php
// Text
$_['text_title'] = 'Plata la livrare';