<?php
// Text
$_['text_title']		   = 'Card de credit / debit (Authorize.Net)';
$_['text_credit_card']     = 'Detalii Credit Card ';

// Entry
$_['entry_cc_owner']       = 'Proprietarul Cardului:';
$_['entry_cc_number']      = 'Număr Card:';
$_['entry_cc_expire_date'] = 'Data expirării cardului:';
$_['entry_cc_cvv2']		   = 'Cod Securitate Card (CVV2):';