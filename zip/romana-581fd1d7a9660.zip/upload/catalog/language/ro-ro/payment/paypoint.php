<?php
// Heading
$_['heading_title']				= 'Vă mulţumim că faceţi cumpărături cu %s .... ';

// Text
$_['text_title']				= 'Card de credit / debit (PayPoint)';
$_['text_response']				= 'Răspuns de la PayPoint:';
$_['text_success']				= '... plata ta a fost primită cu succes.';
$_['text_success_wait']			= '<b><span style="color: #FF0000">Vă rugăm aşteptaţi...</span></b>până ce procesăm comanda dvs.<br>Dacă nu eşti direcţtionat în 10 sec , te rugăm să apeşi <a href="%s">aici</a>.';
$_['text_failure']				= '... Plata a fost anulată!';
$_['text_failure_wait']			= '<b><span style="color: #FF0000">Vă rugăm aşteptaţi...</span></b><br>Dacă nu eşti direcţtionat în 10 sec , te rugăm să apeşi  <a href="%s">aici</a>.';