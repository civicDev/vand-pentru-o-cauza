<?php
// Text
$_['text_title']				= 'Transfer Bancar';
$_['text_instruction']			= 'Instrucţiuni pentru transfer bancar';
$_['text_description']			= 'Vă rugăm să transferaţi valoarea comenzii în următorul cont bancar.';
$_['text_payment']				= 'Comanda va fi livrată doar după confirmarea plății.';