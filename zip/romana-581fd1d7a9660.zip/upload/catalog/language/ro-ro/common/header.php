<?php
// Text
$_['text_home']          = 'Prima Pagină';
$_['text_wishlist']      = 'Wish List (%s)';
$_['text_shopping_cart'] = 'Coşul meu';
$_['text_category']      = 'Categorii';
$_['text_account']       = 'Contul meu';
$_['text_register']      = 'Înregistrează-te';
$_['text_login']         = 'Autentifică-te';
$_['text_order']         = 'Istoric comenzi';
$_['text_transaction']   = 'Tranzacții';
$_['text_download']      = 'Descărcări';
$_['text_logout']        = 'Ieșire din cont';
$_['text_checkout']      = 'Comandă';
$_['text_search']        = 'Căutare';
$_['text_all']           = 'Vezi tot în';