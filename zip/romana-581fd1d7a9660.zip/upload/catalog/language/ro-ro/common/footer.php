<?php
// Text
$_['text_information']  = 'Informaţii';
$_['text_service']      = 'Servicii Clienţi';
$_['text_extra']        = 'Extra';
$_['text_contact']      = 'Contact';
$_['text_return']       = 'Returnări';
$_['text_sitemap']      = 'Harta sitului';
$_['text_manufacturer'] = 'Producători';
$_['text_voucher']      = 'Vouchere cadou';
$_['text_affiliate']    = 'Afiliaţi';
$_['text_special']      = 'Oferte speciale';
$_['text_account']      = 'Contul meu';
$_['text_order']        = 'Istoric comenzi';
$_['text_wishlist']     = 'Wish List';
$_['text_newsletter']   = 'Newsletter';
$_['text_powered']      = '%s &copy; %s';