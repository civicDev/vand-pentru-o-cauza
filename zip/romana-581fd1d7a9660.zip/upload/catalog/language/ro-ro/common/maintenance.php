<?php
// Heading
$_['heading_title']    = 'Mentenanţă';

// Text
$_['text_maintenance'] = 'Mentenanţă';
$_['text_message']     = '<h1>În acest moment efectuăm lucrări de mentenanţă la site. <br/>Ne vom întoarce online cât de repede posibil. Vă rugăm să reveniţi mai târziu.</h1>';