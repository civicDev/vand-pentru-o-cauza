<?php
// Text
$_['text_title']          = 'Comandă prin PayPal Express';
$_['text_canceled']       = 'Succes: Ai anulat această plată!';

// Button
$_['button_cancel']       = 'Anulează abonament';

// Error
$_['error_not_cancelled'] = 'Eroare: %s';
$_['error_not_found']     = 'Abonamentul nu poate fi anulat!';