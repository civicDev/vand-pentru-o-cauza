<?php
// Text
$_['text_success'] = 'Succes: Sesiunea API a fost începută!';

// Error
$_['error_key']  = 'Avertisment: Cheie API incorecta!';
$_['error_ip']   = 'Avertisment: IP-ul tau %s nu are access la API!';