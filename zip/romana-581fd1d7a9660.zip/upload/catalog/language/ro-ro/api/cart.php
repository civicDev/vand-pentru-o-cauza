<?php
// Text
$_['text_success']     = 'Succes: Ai modificat coșul tău de cumpărături!';

// Error
$_['error_permission'] = 'Atenție: Nu ai permisiunile necesare pentru a accesa API-ul!';
$_['error_stock']      = 'Produsele marcate cu *** nu sunt disponibile în cantitatea dorită sau nu sunt în stoc deloc!';
$_['error_minimum']    = 'Cantitatea minima de %s ce poate fi comandată este %s!';
$_['error_store']      = 'Produsul nu poate fi cumpărat de la magazinul selectat!';
$_['error_required']   = '%s este obligatoriu!';