<?php
// Heading
$_['heading_title'] = 'Cele mai vândute';

// Text
$_['text_tax']      = 'Fără TVA:';