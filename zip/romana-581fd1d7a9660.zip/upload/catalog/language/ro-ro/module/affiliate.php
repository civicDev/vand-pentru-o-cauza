<?php
// Heading
$_['heading_title']    = 'Afiliaţi';

// Text
$_['text_register']    = 'Înregistrează-te';
$_['text_login']       = 'Autentifică-te';
$_['text_logout']      = 'Iesire din cont';
$_['text_forgotten']   = 'Am uitat parola';
$_['text_account']     = 'Contul meu';
$_['text_edit']        = 'Editează informațiile contului';
$_['text_password']    = 'Schimbă parola';
$_['text_payment']     = 'Opţiuni de plată';
$_['text_tracking']    = 'Tracking Afiliaţi';
$_['text_transaction'] = 'Tranzacții';
