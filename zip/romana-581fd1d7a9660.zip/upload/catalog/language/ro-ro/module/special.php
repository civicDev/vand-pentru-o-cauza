<?php
// Heading
$_['heading_title'] = 'Oferte speciale';

// Text
$_['text_tax']      = 'Fără TVA:';