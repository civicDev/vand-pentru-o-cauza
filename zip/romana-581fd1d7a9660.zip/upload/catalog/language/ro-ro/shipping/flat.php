<?php
// Text
$_['text_title']       = 'Taxă fixă de livrare';
$_['text_description'] = 'Valoarea taxei fixe de livrare';