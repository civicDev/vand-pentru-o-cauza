<?php
// Text
$_['text_title']       = 'Pe Produs';
$_['text_description'] = 'Rata de livrare pe produs';