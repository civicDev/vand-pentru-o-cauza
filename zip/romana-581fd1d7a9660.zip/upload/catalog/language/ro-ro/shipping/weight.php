<?php
// Text
$_['text_title']  = 'Livrare bazată pe greutate';
$_['text_weight'] = 'Greutate:';