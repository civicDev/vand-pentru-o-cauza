<?php
// Heading
$_['heading_title'] = 'Cod de verificare';

// Entry
$_['entry_captcha'] = 'Itrodu codul din imaginea de mai jos';

// Error
$_['error_captcha'] = 'Codul de verificare este incorect!';
