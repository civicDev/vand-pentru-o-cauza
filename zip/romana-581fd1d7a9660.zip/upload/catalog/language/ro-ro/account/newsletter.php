<?php
// Heading
$_['heading_title']    = 'Înscrie-te la Newsletter';

// Text
$_['text_account']     = 'Cont';
$_['text_newsletter']  = 'Newsletter';
$_['text_success']     = 'Succes: Înscrierea ta a fost realizată cu succes!';

// Entry
$_['entry_newsletter'] = 'Înscriere';
