<?php
// Heading
$_['heading_title']     = 'Descărcări';

// Text
$_['text_account']      = 'Cont';
$_['text_downloads']    = 'Descărcări';
$_['text_empty']        = 'Nu ai comenzi ce conțin descărcări!';

// Column
$_['column_order_id']   = 'ID comandă:';
$_['column_name']       = 'Nume:';
$_['column_size']       = 'Mărime:';
$_['column_date_added'] = 'Data adăugării:';